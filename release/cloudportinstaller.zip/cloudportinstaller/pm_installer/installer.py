"""Оркестратор: ссылка → загрузка → распаковка → анализ → раскладка по путям прошивки."""
import enum
import logging
import os
import shutil
import stat
import tempfile
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

from . import cache, portinfo, space
from .archives import extract, uncompressed_size
from .manager import format_size
from .clouds import CloudProvider, RemoteDir, RemoteFile, get_provider, normalize_url
from .constants import is_archive_name
from .errors import (CancelledError, ConflictAbort, InstallerError, InvalidLinkError,
                     wrap_oserror)
from .firmware import FirmwareProfile, detect, env_cfw_name, resolve_targets
from .layout import analyze
from .settings import Settings

log = logging.getLogger("pm_installer.installer")


class ConflictAction(enum.Enum):
    OVERWRITE = "overwrite"
    SKIP = "skip"
    BACKUP = "backup"
    ABORT = "abort"


ConflictResolver = Callable[[Path, str], ConflictAction]      # (существующий путь, "папка"/"файл")
ProgressFn = Callable[[str, float, str], None]                # (этап, доля 0..1 или -1, сообщение)
Chooser = Callable[[List[RemoteFile]], List[RemoteFile]]


@dataclass
class InstallReport:
    archive: str
    firmware: str
    port_dir: Path
    script_dir: Path
    installed: List[str] = field(default_factory=list)
    skipped: List[str] = field(default_factory=list)
    backups: List[str] = field(default_factory=list)
    ignored: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    info: Optional[object] = None                      # PortInfo из port.json
    names: List[str] = field(default_factory=list)     # имена установленных скриптов и папок (для истории)

    def summary(self) -> List[str]:
        lines = [f"Архив: {self.archive}", f"Прошивка: {self.firmware}"]
        lines += [f"Установлено: {x}" for x in self.installed]
        lines += [f"Пропущено: {x}" for x in self.skipped]
        lines += [f"Резервная копия: {x}" for x in self.backups]
        lines += [f"Не установлено (не часть порта): {x}" for x in self.ignored]
        lines += [f"Внимание: {x}" for x in self.warnings]
        if self.info:
            lines += self.info.lines()
        return lines


class PortInstaller:
    def __init__(self, settings: Settings, profiles: Dict[str, FirmwareProfile], *,
                 root: str = "", resolver: Optional[ConflictResolver] = None,
                 progress: Optional[ProgressFn] = None,
                 cancel: Optional[threading.Event] = None,
                 temp_default: Optional[Path] = None, allow_sudo: bool = True,
                 session=None):
        self.settings = settings
        self.profiles = profiles
        self.root = root
        self.resolver = resolver
        self._progress_cb = progress
        self.cancel = cancel or threading.Event()
        self.allow_sudo = allow_sudo
        self.session = session
        self.history = None            # History: куда записывать установленное
        self.temp_root = Path(settings.temp_dir) if settings.temp_dir else Path(
            temp_default or Path(tempfile.gettempdir()) / "pm_installer")

    # ------------------------------------------------------------ вспомогательное

    _batch = None        # (номер, всего) при установке нескольких архивов

    def _title(self, text: str) -> str:
        return f"[{self._batch[0]} из {self._batch[1]}] {text}" if self._batch and self._batch[1] > 1 else text

    @staticmethod
    def _clock(sec: float) -> str:
        sec = max(0, int(sec))
        return f"{sec // 60}:{sec % 60:02d}"

    def _progress(self, stage: str, frac: float, msg: str = "") -> None:
        if self._progress_cb:
            self._progress_cb(stage, frac, msg)

    def _check_cancel(self) -> None:
        if self.cancel.is_set():
            raise CancelledError("Установка отменена.")

    def firmware_key(self) -> str:
        want = self.settings.firmware
        if want and want != "auto":
            if want not in self.profiles:
                raise InstallerError(f"Неизвестная прошивка «{want}». Доступны: {', '.join(self.profiles)}.")
            return want
        key = detect(self.profiles, self.root, env_cfw_name(self.root))
        if key is None:
            raise InstallerError("Не удалось определить прошивку автоматически. Выберите её в настройках.")
        log.info("Прошивка определена автоматически: %s", key)
        return key

    # ------------------------------------------------------------ облако

    def list_remote(self, url: Optional[str] = None) -> Tuple[CloudProvider, List[RemoteFile]]:
        url = normalize_url(self.settings.url if url is None else url)
        provider = get_provider(url, self.settings.cloud, self.session)
        log.info("Облако: %s, ссылка: %s", provider.key, url)
        self._progress("list", -1, "Чтение ссылки…")
        files = [f for f in provider.list_files(url) if not f.name or is_archive_name(f.name)]
        if not files:
            raise InvalidLinkError("По ссылке не найдено архивов .zip / .7z / .rar.")
        return provider, files

    def open_dir(self, path: Optional[str] = None, prefix: str = "", url: Optional[str] = None):
        """Одна папка облака: (провайдер, подпапки, архивы). Для корня без содержимого — ошибка."""
        url = normalize_url(self.settings.url if url is None else url)
        provider = get_provider(url, self.settings.cloud, self.session)
        log.info("Облако: %s, ссылка: %s, папка: %s", provider.key, url, path or "/")
        dirs, files = provider.list_dir(url, path, prefix)
        files = [f for f in files if not f.name or is_archive_name(f.name)]
        if path is None and not files and not dirs:
            raise InvalidLinkError("По ссылке не найдено архивов .zip / .7z / .rar.")
        return provider, dirs, files

    def install(self, url: Optional[str] = None, choose: Optional[Chooser] = None) -> List[InstallReport]:
        """Полный цикл по ссылке. Для папки с несколькими архивами нужен choose()."""
        provider, files = self.list_remote(url)
        if len(files) > 1 or (files and files[0].meta.get("folder") and choose is not None):
            if choose is None:
                raise InvalidLinkError("В папке несколько архивов — выберите нужный.")
            files = choose(files)
        return self.install_remote(provider, files)

    def install_remote(self, provider: CloudProvider, files: List[RemoteFile],
                       source: Optional[dict] = None) -> List[InstallReport]:
        """Скачивает и устанавливает выбранные файлы (список уже показан пользователю)."""
        reports = []
        dl_dir = self.temp_root / "download"
        for n, rf in enumerate(files, 1):
            self._check_cancel()
            self._batch = (n, len(files))
            label = rf.name or "архив"

            t0 = time.monotonic()

            def on_dl(done: int, total: Optional[int], _l=label, _t0=t0):
                speed = done / max(time.monotonic() - _t0, 0.001)
                lines = [self._title(f"Загрузка {_l}")]
                if total:
                    eta = (total - done) / speed if speed > 0 else 0
                    lines += [f"{format_size(done)} из {format_size(total)}",
                              f"{format_size(int(speed))}/с · осталось {self._clock(eta)}"]
                else:
                    lines += [f"Скачано {format_size(done)}", f"{format_size(int(speed))}/с"]
                self._progress("download", done / total if total else -1, "\n".join(lines))

            keep = self.settings.keep_downloads
            src_url = (source or {}).get("url") or self.settings.url
            ident = provider._identity(rf)
            cached = cache.lookup(self.temp_root, src_url, ident, rf.name, rf.size) if keep else None
            if cached is not None:
                self._progress("download", 1.0, f"{self._title('Архив уже скачан')}\n{label}\nберу из кэша")
                path = cached
            else:
                if rf.size:    # место под скачанный архив; под распаковку проверим, когда узнаем его содержимое
                    space.check(dl_dir, space.needed(rf.size), "для загрузки")

                def on_retry(i, total_tries, err, _l=label):
                    self._progress("download", -1, f"{self._title(f'Загрузка {_l}')}\n"
                                   f"Связь оборвалась — повтор {i} из {total_tries}, докачиваю…")
                path = provider.download(rf, dl_dir, on_dl, self.cancel, on_retry)
                if keep:
                    try:
                        path = cache.store(self.temp_root, src_url, ident, rf.name, path)
                    except OSError:
                        log.exception("Не удалось сохранить архив в кэш")
            try:
                rep = self.install_archive(path)
                reports.append(rep)
                if self.history is not None and source:
                    self.history.record(source, rf, rep.names)
            finally:
                if not keep:
                    try:
                        path.unlink()
                    except OSError:
                        pass
        self._batch = None
        return reports

    # ------------------------------------------------------------ установка архива

    def install_archive(self, archive: Path) -> InstallReport:
        archive = Path(archive)
        profile = self.profiles[self.firmware_key()]
        targets = resolve_targets(profile, self.root, self.allow_sudo)   # рано падаем при нехватке прав
        report = InstallReport(archive.name, profile.label, targets.port_dir, targets.script_dir)

        try:
            self.temp_root.mkdir(parents=True, exist_ok=True)
            work = Path(tempfile.mkdtemp(prefix="extract_", dir=self.temp_root))
        except OSError as e:
            raise wrap_oserror(e, self.temp_root) from e
        try:
            unpacked = uncompressed_size(archive)
            if unpacked:
                space.check(work, space.needed(unpacked), "для распаковки")
                if not space.same_device(work, targets.port_dir):      # перенос копированием, а не переименованием
                    space.check(targets.port_dir, space.needed(unpacked), "в папке портов")
            title = self._title(f"Распаковка {archive.name}")
            self._progress("extract", -1, title + "\nПодготовка…")

            def on_extract(ep):
                lines = [title]
                if ep.files_total:
                    lines.append(f"Файлов: {ep.files_done} из {ep.files_total}")
                if ep.current:
                    lines.append(ep.current)
                if ep.bytes_total:
                    lines.append(f"{format_size(ep.bytes_done)} из {format_size(ep.bytes_total)}")
                self._progress("extract", ep.frac, "\n".join(lines))
            extract(archive, work, on_extract, self.cancel)
            self._check_cancel()
            layout = analyze(work)
            report.warnings += layout.warnings
            report.ignored += [p.name for p in layout.ignored]
            try:
                report.info = portinfo.read(work)
            except Exception:      # справочные данные не должны ломать установку
                log.exception("port.json")
            log.info("Порт: sh=%s, папки=%s", [s.name for s in layout.scripts],
                     [d.name for d in layout.port_dirs])

            items = [(d, targets.port_dir, "папка") for d in layout.port_dirs] + \
                    [(s, targets.script_dir, "файл") for s in layout.scripts]
            for i, (src, dst_dir, kind) in enumerate(items):
                self._check_cancel()
                self._progress("install", i / len(items),
                               f"{self._title('Копирование в папки порта')}\n{src.name}\n{kind}: {i + 1} из {len(items)}")
                self._place(src, dst_dir, kind, report)
            self._progress("install", 1.0, "Готово")
        finally:
            shutil.rmtree(work, ignore_errors=True)
        log.info("Установка завершена: %s", report.summary())
        return report

    # ------------------------------------------------------------ раскладка

    def _decide(self, dst: Path, kind: str) -> ConflictAction:
        pol = self.settings.conflict_policy
        if pol == "overwrite":
            return ConflictAction.OVERWRITE
        if pol == "skip":
            return ConflictAction.SKIP
        if pol == "backup":
            return ConflictAction.BACKUP
        if self.resolver is None:
            raise ConflictAbort(f"«{dst.name}» уже существует. Выберите в настройках, что делать при конфликте.")
        return self.resolver(dst, kind)

    def _place(self, src: Path, dst_dir: Path, kind: str, report: InstallReport) -> None:
        dst = dst_dir / src.name
        is_script = src.suffix.lower() == ".sh" and kind == "файл"
        try:
            if os.path.lexists(dst):
                action = self._decide(dst, kind)
                log.info("Конфликт %s → %s", dst, action.value)
                if action is ConflictAction.ABORT:
                    raise ConflictAbort("Установка прервана пользователем.")
                if action is ConflictAction.SKIP:
                    report.skipped.append(f"{dst.name} (уже существует)")
                    return
                if action is ConflictAction.BACKUP:
                    bak = dst.with_name(f"{dst.name}.bak-{time.strftime('%Y%m%d-%H%M%S')}")
                    os.rename(dst, bak)
                    report.backups.append(bak.name)
                    shutil.move(str(src), str(dst))
                else:   # OVERWRITE: старое сначала откладываем, чтобы откатиться при сбое
                    old = dst.with_name(f".{dst.name}.old-{os.getpid()}")
                    os.rename(dst, old)
                    try:
                        shutil.move(str(src), str(dst))
                    except Exception:
                        if os.path.lexists(dst):
                            shutil.rmtree(dst, ignore_errors=True) if dst.is_dir() else dst.unlink()
                        os.rename(old, dst)
                        raise
                    shutil.rmtree(old, ignore_errors=True) if old.is_dir() else old.unlink()
            else:
                shutil.move(str(src), str(dst))
        except OSError as e:
            raise wrap_oserror(e, dst) from e
        report.installed.append(f"{dst.name} → {dst_dir}")
        report.names.append(dst.name)
        if is_script:
            self._make_executable(dst, report)

    @staticmethod
    def _make_executable(path: Path, report: InstallReport) -> None:
        try:
            os.chmod(path, path.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
        except OSError as e:
            log.warning("chmod +x %s: %s", path, e)
        if not os.access(path, os.X_OK):
            report.warnings.append(
                f"Не удалось выставить право на исполнение для «{path.name}» "
                "(файловая система может не поддерживать права).")
